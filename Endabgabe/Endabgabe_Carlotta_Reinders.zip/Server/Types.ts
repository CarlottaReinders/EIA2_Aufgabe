interface allScores {
    [key: string]: string;
}

interface Player {
    name: string;
    score: number;
}